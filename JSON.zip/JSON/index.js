const fs = require('fs');

fs.readFile('C:/JSON/adidas_usa.json', 'utf8', (error, data) => {
  if (error) {
    console.error('Error:', error);
    return;
  }

  // JSON data is available here
  const jsonData = JSON.parse(data);
  console.log(jsonData);
});




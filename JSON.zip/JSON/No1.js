const fs = require('fs');

function displayTopSellingPrices(filePath) {
  fs.readFile(filePath, 'utf8', (error, data) => {
    if (error) {
      console.error('Error:', error);
      return;
    }

    const jsonData = JSON.parse(data);
    const sortedPrices = jsonData.sort((a, b) => b.selling_price - a.selling_price);
    const topPrices = sortedPrices.slice(0, 5).map(item => item.selling_price);
    console.log('Top 5 Selling Prices:', topPrices);
  });
}

// Usage: Replace 'C:/JSON/adidas_usa.json' with your file path
displayTopSellingPrices('C:/JSON/adidas_usa.json');


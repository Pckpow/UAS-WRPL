import csv
import json

def csv_to_json(csv_file_path, json_file_path):
    # Open the CSV file for reading
    with open(csv_file_path, 'r') as csv_file:
        # Read the CSV data using a dictionary reader
        csv_data = csv.DictReader(csv_file)

        # Convert the CSV data into a list of dictionaries
        json_data = list(csv_data)

    # Write the JSON data to a file
    with open(json_file_path, 'w') as json_file:
        json.dump(json_data, json_file, indent=4)

# Example usage:
csv_file_path = 'C:/Users/mahdi/Downloads/adidas_usa.scv.csv'
json_file_path = 'C:/Users/mahdi/Downloads/adidas_usa.json'
csv_to_json(csv_file_path, json_file_path)
